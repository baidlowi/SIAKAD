<?php
//...


defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_course';
$plugin->version = 2020071900;
$plugin->requires = 2016120500; // Moodle version